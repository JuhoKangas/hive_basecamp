/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jkangas <jkangas@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/06/05 11:34:19 by jkangas           #+#    #+#             */
/*   Updated: 2021/06/05 19:21:01 by jkangas          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include "sudoku.h"

int		find_empty_location(int **grid, int row, int col);
int		check_placement(int **grid, int row, int col, int num);

int		solve_sudoku(int **grid, int row, int col)
{
	int num;
	
	// check if we're at the end to prevent further backtracking
	if (row == 8 && col == 9)
		return (1);
	// go to the next row if we're at the end of the column
	if (col == 9)
	{
		row++;
		col = 0;
	}
	if (grid[row][col] > 0)
		return (solve_sudoku(grid, row, col + 1));
	num = 1;
	while (num <= 9)
	{
		if (check_placement(grid, row, col, num))
		{
			grid[row][col] = num;
			if (solve_sudoku(grid, row, col + 1))
				return (1);
			grid[row][col] = 0;
		}
		num++;
	}
	// this triggers the backtracking
	return (0);
}

int		check_row(int **grid, int row, int num)
{
	int col;

	col = 0;
	while (col < 9)
	{
		if(grid[row][col++] == num)
			return (0);
	}
	return (1);
}

int		check_col(int **grid, int col, int num)
{
	int row;

	row = 0;
	while (row < 9)
	{
		if(grid[row++][col] == num)
			return (0);
	}
	return (1);
}

int		check_box(int **grid, int box_row, int box_col, int num)
{
	int row;
	int col;

	row = 0;
	while (row < 3)
	{
		col = 0;
		while (col < 3)
		{
			if (grid[row + box_row][col + box_col] == num)
				return (0);
			col++;
		}
		row++;
	}
	return (1);
}

int		check_placement(int **grid, int row, int col, int num)
{
	int row_start;
	int col_start;

	row_start = row - row % 3;
	col_start = col - col % 3;
	if (check_row(grid, row, num) 
		&& check_col(grid, col, num)
		&& check_box(grid, row_start, col_start, num)
		&& grid[row][col] == 0)
	{
		return (1);
	}
	return (0);
}

void	print_grid(int **grid)
{
	int i;
	int j;

	i = 0;
	j = 0;
	while (i < 9)
	{
		j = 0;
		while (j < 9)
		{
			printf("%d ", grid[i][j++]);
		}
		printf("\n");
		i++;
	}
}

int		main(int argc, char **argv)
{
	int 	**grid;
	int 	i;
	int 	j;
	
	i = 0;
	grid = (int **)malloc(sizeof(int *) * 9);
	while (i < argc - 1)
	{
		grid[i] = (int *)malloc(sizeof(int) * 9);
		j = 0;
		while (j < 9)
		{
			if (argv[i + 1][j] == '.')
				grid[i][j] = 0;
			else if (argv[i + 1][j] >= '1' && argv[i + 1][j] <= '9')
				grid[i][j] = argv[i + 1][j] - '0';
			j++;
		}
		i++;
	}
	if (solve_sudoku(grid, 0, 0) == 1)
	{
		print_grid(grid);
	}
	else
		printf("No solution");
}

// test segment : "9...7...." "2...9..53" ".6..124.." "84...1.9." "5.....8.." ".31..4..." "..37..68." ".9..5.741" "47......."