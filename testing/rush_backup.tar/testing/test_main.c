/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test_main.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: atenhune <atenhune@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/06/05 07:43:58 by ppikkane          #+#    #+#             */
/*   Updated: 2021/06/05 15:37:42 by atenhune         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

void	ft_putstr(char *str);
void	ft_putchar(char c);

/* run test by: ./test < sudoku_solver_program */

int main(void)
{
	char 	input;

	int array[10][10];
	int nums[9] = {0,0,0,0,0,0,0,0,0};
	int i;
	int j;
	int error_flag;
	int error_pos[2] = {0,0};

	i = 0;
	j = 0;
	error_flag = 0;
	
	// Read input
	while ((input=getchar()) != EOF) {
		
		if (input != ' ' && input != '\n')
		{
			array[i][j] = atoi(&input);
		 	j++;
		}
		if (input == '\n')
		{
			array[i][j] = 0;
			i++;
			j = 0;
		}

	}
	while (j < 9)
	{
		array[i][j] = 0;
		j++;
	}
	i = 0;
	j = 0;

	// Horizontal collision detection
	while (array[i][j] != 0)
	{
		while (array[i][j] != 0)
		{
			if (nums[(array[i][j] - 1)] == 1)
			{
				// Number collision
				error_flag = 1;
				error_pos[0] = j;
				error_pos[1] = i;
			}
			nums[(array[i][j] - 1)] = 1;
			ft_putchar(array[i][j] + '0');
			ft_putchar(' ');
			j++;
		}
		j = 0;
		while (j < 9)
		{
			nums[j] = 0;
			j++;
		}
		ft_putchar('\n');
		j = 0;
		i++;
	}
	if (error_flag == 1)
	{
		// out: Horizontal collision at(x, y) x=column y=row
		
		ft_putstr("Horizontal collision at (");
		ft_putchar((error_pos[0] + 1) +'0');
		ft_putchar(',');
		ft_putchar((error_pos[1] + 1) + '0');
		ft_putstr(")");
		ft_putchar('\n');
		return (0);
	}
	// Vertical collision detection
	i = 0;
	while (i < 9)
	{
		nums[i] = 0;
		i++;
	}
	i = 0;
	j = 0;
	while (array[i][j] != 0)
	{
		while (array[i][j] != 0)
		{
			if (nums[(array[i][j] - 1)] == 1)
			{
				// Number collision
				error_flag = 1;
				error_pos[0] = j;
				error_pos[1] = i;
			}
			nums[(array[i][j] - 1)] = 1;
			i++;
		}
		i = 0;
		while (i < 9)
		{
			nums[i] = 0;
			i++;
		}
		i = 0;
		j++;
	}
	if (error_flag == 1)
	{
		// out: Horizontal collision at(x, y) x=column y=row
		
		ft_putstr("Vertical collision at (");
		ft_putchar(error_pos[0] + '0');
		ft_putchar(',');
		ft_putchar((error_pos[1] + 1) + '0');
		ft_putstr(")");
		ft_putchar('\n');
		return (0);
	}
	ft_putstr("Everything OK");
	ft_putstr("\n");
	return (0);
}