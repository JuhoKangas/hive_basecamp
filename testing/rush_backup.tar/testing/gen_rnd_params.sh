#!/bin/sh

rnd_1=$(shuf -n 9 shuf.txt | tr -d '\n')
rnd_2=$(shuf -n 9 shuf.txt | tr -d '\n')
rnd_3=$(shuf -n 9 shuf.txt | tr -d '\n')
rnd_4=$(shuf -n 9 shuf.txt | tr -d '\n')
rnd_5=$(shuf -n 9 shuf.txt | tr -d '\n')
rnd_6=$(shuf -n 9 shuf.txt | tr -d '\n')
rnd_7=$(shuf -n 9 shuf.txt | tr -d '\n')
rnd_8=$(shuf -n 9 shuf.txt | tr -d '\n')
rnd_9=$(shuf -n 9 shuf.txt | tr -d '\n')

# Change ./test_solver_juho to your solver program
./test_solver_juho "$rnd_1" "$rnd_2" "$rnd_2" "$rnd_3" "$rnd_4" "$rnd_5" "$rnd_6" "$rnd_7" "$rnd_8" "$rnd_9"